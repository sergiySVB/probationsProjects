package ru.mail.sergey_balotnikov.taskapi.teamFilter.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.core.view.get
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_filter.view.*
import ru.mail.sergey_balotnikov.taskapi.R
import ru.mail.sergey_balotnikov.taskapi.util.Constants
import ru.mail.sergey_balotnikov.taskapi.Router as Router

class FragmentTeamFilter: Fragment() {
    companion object{
        fun newInstance() = FragmentTeamFilter()
    }

    private lateinit var checkDivision: RadioGroup
    private lateinit var checkConference:RadioGroup
    private lateinit var cancel:Button
    private lateinit var apply:Button
    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        router = activity as Router
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_filter, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checkDivision=view.rgDivision
        checkConference=view.rgConference
        cancel=view.btnCancel
        cancel.setOnClickListener{cancel()}
        apply=view.btnApply
        apply.setOnClickListener{applyFilter()}

    }

    override fun onResume() {
        super.onResume()
        initFilter()
    }

    private fun initFilter() {
        val filter=router.getFilter()

        when (filter.teamDivision){
            "Southeast" -> checkDivision.check(R.id.rbSoutheastDivision)
            "Southwest" -> checkDivision.check(R.id.rbSouthwestDivision)
            "Northwest" -> checkDivision.check(R.id.rbNorthwestDivision)
            "Pacific" -> checkDivision.check(R.id.rbPacificDivision)
            "Central" -> checkDivision.check(R.id.rbCentralDivision)
            "Atlantic" -> checkDivision.check(R.id.rbAtlanticDivision)
            ""-> checkDivision.check(R.id.rbNoDivision)
        }
        when(filter.teamConference){
            "East" -> checkConference.check(R.id.rbEast)
            "West" -> checkConference.check(R.id.rbWest)
            "" -> checkConference.check(R.id.rbNoConference)
        }


    }
    private fun applyFilter(){
        val filter = router.getFilter()

        when(checkDivision.checkedRadioButtonId){
            R.id.rbAtlanticDivision -> filter.teamDivision="Atlantic"
            R.id.rbSoutheastDivision -> filter.teamDivision="Southeast"
            R.id.rbSouthwestDivision -> filter.teamDivision="Southwest"
            R.id.rbNorthwestDivision -> filter.teamDivision="Northwest"
            R.id.rbPacificDivision -> filter.teamDivision="Pacific"
            R.id.rbCentralDivision -> filter.teamDivision="Central"
            R.id.rbNoDivision -> filter.teamDivision=""
        }
        when(checkConference?.checkedRadioButtonId){
            R.id.rbNoConference -> filter.teamConference=""
            R.id.rbEast -> filter.teamConference="East"
            R.id.rbWest -> filter.teamConference="West"
        }

        router.updateFilter(filter)
        router.setCurrentFragment(Constants.TAG_TEEM_LIST_SCREEN)
        router.showCurrentFragment()

    }
    private fun cancel(){
        val activity = activity
        router.setCurrentFragment(Constants.TAG_TEEM_LIST_SCREEN)
        router.showCurrentFragment()
    }
    private fun getArrayFromRadioGroup(group: RadioGroup): List<RadioButton>{
        val buttons = ArrayList<RadioButton>()
        val count = group.childCount
        for(i in 0 until count){
            if(group[i] is RadioButton){
                buttons.add(group[i] as RadioButton)
            }
        }
        return buttons
    }

}