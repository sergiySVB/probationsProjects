package ru.mail.sergey_balotnikov.taskapi.teamDetails.presenter

import ru.mail.sergey_balotnikov.taskapi.teamDetails.model.ItemDetailsData

interface ItemDetailsView {
    fun onShowItemDetails(itemDetailsData: ItemDetailsData)
    fun onExceptionItemDetails()
}