package ru.mail.sergey_balotnikov.taskapi.teamDetails.view

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import ru.mail.sergey_balotnikov.taskapi.R
import ru.mail.sergey_balotnikov.taskapi.teamList.model.Team
import ru.mail.sergey_balotnikov.taskapi.util.Constants

class FragmentTeamDelails: Fragment() {
    companion object{
        fun newInstance() = FragmentTeamDelails ()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d("SVB", "id is "+arguments?.getInt(Constants.KEY_TEAM, 0))
        return inflater.inflate(R.layout.fragment_team_details, container, false)
    }
}