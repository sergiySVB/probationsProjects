package ru.mail.sergey_balotnikov.taskapi.teamDetails.model

class ItemDetailsData {

}