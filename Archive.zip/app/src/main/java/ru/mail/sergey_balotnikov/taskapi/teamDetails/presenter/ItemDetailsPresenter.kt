package ru.mail.sergey_balotnikov.taskapi.teamDetails.presenter

import ru.mail.sergey_balotnikov.taskapi.teamDetails.model.ItemDetailsData

interface ItemDetailsPresenter {
    fun getItemDetailsById(id:Int):ItemDetailsData
}