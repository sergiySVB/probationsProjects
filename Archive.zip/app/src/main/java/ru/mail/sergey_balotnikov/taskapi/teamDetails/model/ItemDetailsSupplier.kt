package ru.mail.sergey_balotnikov.taskapi.teamDetails.model

import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import ru.mail.sergey_balotnikov.nbateam.model.SearchPlayersRepository
import ru.mail.sergey_balotnikov.nbateam.model.services.GetPlayersService
import ru.mail.sergey_balotnikov.taskapi.teamDetails.model.data.ResultPlayers

class ItemDetailsSupplier {

    private val repository = SearchPlayersRepository(GetPlayersService.create())

    fun getPlayers(teamId: Int): Single<ResultPlayers> =
        repository.searchPlayers()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .map { ResultPlayers(it.players.filter { it.team.teamId==teamId }) }
}