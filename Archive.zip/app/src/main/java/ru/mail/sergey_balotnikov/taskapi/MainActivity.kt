package ru.mail.sergey_balotnikov.taskapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import ru.mail.sergey_balotnikov.taskapi.teamDetails.view.FragmentTeamDelails
import ru.mail.sergey_balotnikov.taskapi.teamList.view.FragmentTeamList
import ru.mail.sergey_balotnikov.taskapi.teamFilter.view.FragmentTeamFilter
import ru.mail.sergey_balotnikov.taskapi.teamList.model.Team
import ru.mail.sergey_balotnikov.taskapi.util.Constants

class MainActivity : AppCompatActivity(), Router {

    private var activeFragmentName: String = Constants.TAG_TEEM_LIST_SCREEN
    private var filter = Team(null, "", "",
        "", "", "", "")
    private var team = Team(null, "", "",
        "", "", "", "")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()
        showCurrentFragment()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putSerializable(Constants.KEY_FILTER, filter)
        outState.putSerializable(Constants.KEY_TEAM, team)
        outState.putString(Constants.KEY_FRAGMENT, activeFragmentName)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        filter = savedInstanceState.getSerializable(Constants.KEY_FILTER) as Team
        team = savedInstanceState.getSerializable(Constants.KEY_TEAM) as Team
        activeFragmentName = savedInstanceState.getString(Constants.KEY_FRAGMENT)?:
                FragmentTeamList::class.java.simpleName
        super.onRestoreInstanceState(savedInstanceState)
    }

    override fun showCurrentFragment() {
        when (activeFragmentName) {
            Constants.TAG_TEEM_LIST_SCREEN -> showTeamList()
            Constants.TAG_TEEM_DETAILS_SCREEN -> showTeamDetails()
            Constants.TAG_TEEM_FILTER_SCREEN -> showFilterScreen()
            else -> FragmentTeamList.newInstance()
        }
    }

    private fun showTeamDetails() {
        val fragmentTeamDetails = FragmentTeamDelails.newInstance()
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragmentTeamDetails, FragmentTeamList::class.java.simpleName)
            .addToBackStack(null)
            .commit()
    }

    fun showTeamList() {
        val fragmentTeamList = FragmentTeamList.newInstance()
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragmentTeamList, FragmentTeamList::class.java.simpleName)
            .commit()
    }


    private fun showFilterScreen() {
        val filterArgs = Bundle()
        filterArgs.putSerializable(Constants.KEY_FILTER, filter)
        val fragmentFilter = FragmentTeamFilter.newInstance()
        supportFragmentManager.beginTransaction()
            .add(R.id.fragmentContainer, fragmentFilter, FragmentTeamList::class.java.simpleName)
            .addToBackStack(null)
            .commit()
    }

    override fun getTeam() = team

    override fun setTeam(team: Team) { this.team = team }

    override fun setCurrentFragment(fragmentName: String) {
        activeFragmentName = fragmentName
    }

    override fun getFilter(): Team {
        return filter
    }

    override fun updateFilter(filter: Team) {
        this.filter =filter
    }

    override fun dropFilter() {
        filter = Team(null, "","","", "",
            "","")
    }
}
