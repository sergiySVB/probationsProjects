package ru.mail.sergey_balotnikov.taskapi.teamDetails.presenter

import ru.mail.sergey_balotnikov.taskapi.Router
import ru.mail.sergey_balotnikov.taskapi.teamDetails.model.ItemDetailsData
import ru.mail.sergey_balotnikov.taskapi.teamDetails.model.ItemDetailsSupplier

class ItemDetailsPresenterImpl: ItemDetailsPresenter {

    private val view: ItemDetailsView
    private val supplier: ItemDetailsSupplier
    private val router: Router

    constructor(view: ItemDetailsView, router: Router) {
        this.view = view
        supplier = ItemDetailsSupplier()
        this.router = router
    }

    override fun getItemDetailsById(id: Int): ItemDetailsData {
        return ItemDetailsData()
    }
}